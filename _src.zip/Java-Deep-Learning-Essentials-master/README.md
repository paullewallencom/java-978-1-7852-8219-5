## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/java-deep-learning-essentials/9781785282195)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1785282190).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Java Deep Learning Essentials

This code is for Java developers who want to know about deep learning algorithms and wish to implement them in applications. Since this code covers the core concepts of and approaches to both machine learning and deep learning, no previous experience in machine learning is required.

Also, we will implement deep learning algorithms with very simple codes, so elementary Java developers will also find this code useful for developing both their Java skills and deep learning skills.

You can also refer to the following books:

* [RESTful Java Web Services](https://www.packtpub.com/web-development/restful-java-web-services?utm_source=github&utm_medium=related&utm_campaign=9781847196460)
* [Service Oriented Architecture with Java](https://www.packtpub.com/application-development/service-oriented-architecture-java?utm_source=github&utm_medium=related&utm_campaign=9781847193216)
* [Java EE 7 with GlassFish 4 Application Server](https://www.packtpub.com/application-development/java-ee-7-glassfish-4-application-server?utm_source=github&utm_medium=related&utm_campaign=9781782176886)
